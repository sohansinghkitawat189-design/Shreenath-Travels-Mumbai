// Sync (laptop + mobile same data) chahiye to Supabase ke URL aur anon key yahan daalo. Khali chhodoge to sirf is device me chalega.
window.CFG={url:'',key:''};
